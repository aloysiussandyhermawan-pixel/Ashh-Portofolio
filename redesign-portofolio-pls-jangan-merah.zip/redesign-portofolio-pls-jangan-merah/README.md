# Redesign Portofolio (pls jangan merah)

A Pen created on CodePen.

Original URL: [https://codepen.io/Xshh/pen/GgoYOWx](https://codepen.io/Xshh/pen/GgoYOWx).

